public class myClass {
}
