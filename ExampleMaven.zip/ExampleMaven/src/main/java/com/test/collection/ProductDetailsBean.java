package com.test.collection;

public class ProductDetailsBean {
    private String pr_name;
    private String pr_id;
    private String qty;
    private String price;



    public String getPr_name() {
        return pr_name;
    }



    public void setPr_name(String pr_name) {
        this.pr_name = pr_name;
    }



    public String getPr_id() {
        return pr_id;
    }



    public void setPr_id(String pr_id) {
        this.pr_id = pr_id;
    }



    public String getQty() {
        return qty;
    }



    public void setQty(String qty) {
        this.qty = qty;
    }



    public String getPrice() {
        return price;
    }



    public void setPrice(String price) {
        this.price = price;
    }



    @Override
    public String toString() {
        return "ProductDetailsBean{" +
                "pr_name='" + pr_name + '\'' +
                ", pr_id='" + pr_id + '\'' +
                ", qty='" + qty + '\'' +
                ", price='" + price + '\'' +
                '}';
    }
}
