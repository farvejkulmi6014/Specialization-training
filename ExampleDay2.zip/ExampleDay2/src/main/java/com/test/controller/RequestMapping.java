package com.test.controller;

public @interface RequestMapping {
}
