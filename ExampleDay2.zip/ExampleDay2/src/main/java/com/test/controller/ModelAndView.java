package com.test.controller;

public class ModelAndView {
    public void setViewName(String hello) {
    }
}
