package com.test.beans;

public class MainApp {
}
