package com.test.singleton;

public class SampleBean {
}
